<?php define('SERVER' , 'localhost');define('DB', 'anubis');define('USER', 'anubis');define('PASSWORD' , '7664');define('cryptKey' , 'zanubis');define('namefolder', 'anubis');
